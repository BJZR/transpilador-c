#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// =============================================================================
// CONFIGURACIÓN - Todas las palabras clave en un solo lugar
// =============================================================================

typedef struct {
    const char *es;
    const char *c;
} Palabra;

// Tabla de traducción completa
static const Palabra MAPA_PALABRAS[] = {
    // Directivas del preprocesador
    {"incluir", "#include"},
    {"definir", "#define"},
    {"si_definido", "#ifdef"},
    {"si_no_definido", "#ifndef"},
    {"fin_si", "#endif"},
    {"linea", "#line"},
    {"pragma", "#pragma"},
    {"error", "#error"},

    // Tipos de datos
    {"entero", "int"},
    {"caracter", "char"},
    {"flotante", "float"},
    {"doble", "double"},
    {"largo", "long"},
    {"corto", "short"},
    {"vacio", "void"},
    {"con_signo", "signed"},
    {"sin_signo", "unsigned"},

    // Modificadores
    {"estatico", "static"},
    {"constante", "const"},
    {"externo", "extern"},
    {"registro", "register"},
    {"volatil", "volatile"},
    {"tipo", "typedef"},
    {"auto", "auto"},
    {"restringir", "restrict"},
    {"en_linea", "inline"},

    // Estructuras
    {"estructura", "struct"},
    {"union", "union"},
    {"enumeracion", "enum"},

    // Control de flujo
    {"si", "if"},
    {"sino", "else"},
    {"mientras", "while"},
    {"para", "for"},
    {"hacer", "do"},
    {"segun", "switch"},
    {"caso", "case"},
    {"por_defecto", "default"},
    {"ir_a", "goto"},

    // Saltos
    {"romper", "break"},
    {"continuar", "continue"},
    {"retornar", "return"},

    // Operadores especiales
    {"tamanio_de", "sizeof"},
    {"tipo_de", "typeof"},

    // Funciones principales
    {"principal", "main"},
    {"imprimir", "printf"},
    {"leer", "scanf"},

    // Marcador de fin
    {NULL, NULL}
};

// Palabras que pueden ir seguidas de '(' sin ser error
static const char* PALABRAS_CON_PARENTESIS[] = {
    "si", "mientras", "para", "segun", "sizeof", "typeof",
    "imprimir", "leer", NULL
};

// =============================================================================
// ESTRUCTURAS Y CONSTANTES
// =============================================================================

typedef enum {
    ESTADO_NORMAL = 0,
    ESTADO_COMENTARIO_LINEA,
    ESTADO_COMENTARIO_BLOQUE,
    ESTADO_STRING,
    ESTADO_CHAR
} Estado;

#define MAX_PALABRA 256
#define MAX_BUFFER 1024

typedef struct {
    FILE *entrada;
    FILE *salida;
    int linea_actual;
    int tiene_errores;
    Estado estado;
    char buffer_palabra[MAX_PALABRA];
    int pos_palabra;
} Transpilador;

// =============================================================================
// FUNCIONES DE UTILIDAD
// =============================================================================

int es_palabra_reservada(const char *palabra) {
    for (int i = 0; MAPA_PALABRAS[i].es != NULL; i++) {
        if (strcmp(palabra, MAPA_PALABRAS[i].es) == 0) {
            return 1;
        }
    }
    return 0;
}

const char* traducir_palabra(const char* palabra) {
    for (int i = 0; MAPA_PALABRAS[i].es != NULL; i++) {
        if (strcmp(palabra, MAPA_PALABRAS[i].es) == 0) {
            return MAPA_PALABRAS[i].c;
        }
    }
    return palabra;
}

int puede_tener_parentesis(const char *palabra) {
    for (int i = 0; PALABRAS_CON_PARENTESIS[i] != NULL; i++) {
        if (strcmp(palabra, PALABRAS_CON_PARENTESIS[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

int es_caracter_palabra(int c) {
    return isalnum(c) || c == '_';
}

int es_espacio_blanco(int c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r';
}

// =============================================================================
// FUNCIONES DE MANEJO DE ERRORES
// =============================================================================

void reportar_error(Transpilador *trans, const char *mensaje, const char *palabra) {
    fprintf(stderr, "Error [línea %d]: %s '%s'\n",
            trans->linea_actual, mensaje, palabra);
    trans->tiene_errores = 1;
}

void validar_uso_palabra_reservada(Transpilador *trans, const char *palabra) {
    if (!es_palabra_reservada(palabra)) {
        return;
    }

    // Saltar espacios en blanco para ver el siguiente carácter
    int c;
    int espacios_saltados = 0;

    do {
        c = fgetc(trans->entrada);
        if (es_espacio_blanco(c)) {
            espacios_saltados++;
        }
    } while (es_espacio_blanco(c) && c != EOF);

    // Verificar si es uso incorrecto
    int es_error = 0;

    if (c == '=') {
        es_error = 1;
    } else if (c == '(' && !puede_tener_parentesis(palabra)) {
        es_error = 1;
    }

    if (es_error) {
        reportar_error(trans,
                       "palabra reservada usada como identificador:", palabra);
    }

    // Devolver el carácter al stream
    if (c != EOF) {
        ungetc(c, trans->entrada);
    }
}

// =============================================================================
// FUNCIONES DE PROCESAMIENTO DE CARACTERES
// =============================================================================

void escribir_caracter(Transpilador *trans, int c) {
    fputc(c, trans->salida);
    if (c == '\n') {
        trans->linea_actual++;
    }
}

void escribir_cadena(Transpilador *trans, const char *str) {
    while (*str) {
        escribir_caracter(trans, *str++);
    }
}

void agregar_a_palabra(Transpilador *trans, int c) {
    if (trans->pos_palabra < MAX_PALABRA - 1) {
        trans->buffer_palabra[trans->pos_palabra++] = c;
    }
}

void procesar_palabra_completa(Transpilador *trans) {
    if (trans->pos_palabra == 0) {
        return;
    }

    trans->buffer_palabra[trans->pos_palabra] = '\0';

    validar_uso_palabra_reservada(trans, trans->buffer_palabra);
    escribir_cadena(trans, traducir_palabra(trans->buffer_palabra));

    trans->pos_palabra = 0;
}

// =============================================================================
// FUNCIONES DE MANEJO DE ESTADOS
// =============================================================================

void procesar_inicio_comentario(Transpilador *trans, int c) {
    int siguiente = fgetc(trans->entrada);

    if (siguiente == '/') {
        escribir_cadena(trans, "//");
        trans->estado = ESTADO_COMENTARIO_LINEA;
    } else if (siguiente == '*') {
        escribir_cadena(trans, "/*");
        trans->estado = ESTADO_COMENTARIO_BLOQUE;
    } else {
        escribir_caracter(trans, c);
        if (siguiente != EOF) {
            ungetc(siguiente, trans->entrada);
        }
    }
}

void procesar_fin_comentario_bloque(Transpilador *trans, int c) {
    escribir_caracter(trans, c);

    if (c == '*') {
        int siguiente = fgetc(trans->entrada);
        if (siguiente == '/') {
            escribir_caracter(trans, siguiente);
            trans->estado = ESTADO_NORMAL;
        } else if (siguiente != EOF) {
            ungetc(siguiente, trans->entrada);
        }
    }
}

void procesar_escape_en_string(Transpilador *trans) {
    int escapado = fgetc(trans->entrada);
    if (escapado != EOF) {
        escribir_caracter(trans, escapado);
    }
}

void procesar_caracter_normal(Transpilador *trans, int c) {
    if (c == '/') {
        procesar_palabra_completa(trans);
        procesar_inicio_comentario(trans, c);
    } else if (c == '"') {
        procesar_palabra_completa(trans);
        escribir_caracter(trans, c);
        trans->estado = ESTADO_STRING;
    } else if (c == '\'') {
        procesar_palabra_completa(trans);
        escribir_caracter(trans, c);
        trans->estado = ESTADO_CHAR;
    } else if (es_caracter_palabra(c)) {
        agregar_a_palabra(trans, c);
    } else {
        procesar_palabra_completa(trans);
        escribir_caracter(trans, c);
    }
}

// =============================================================================
// FUNCIÓN PRINCIPAL DE PROCESAMIENTO
// =============================================================================

void procesar_caracter(Transpilador *trans, int c) {
    switch (trans->estado) {
        case ESTADO_NORMAL:
            procesar_caracter_normal(trans, c);
            break;

        case ESTADO_COMENTARIO_LINEA:
            escribir_caracter(trans, c);
            if (c == '\n') {
                trans->estado = ESTADO_NORMAL;
            }
            break;

        case ESTADO_COMENTARIO_BLOQUE:
            procesar_fin_comentario_bloque(trans, c);
            break;

        case ESTADO_STRING:
            escribir_caracter(trans, c);
            if (c == '\\') {
                procesar_escape_en_string(trans);
            } else if (c == '"') {
                trans->estado = ESTADO_NORMAL;
            }
            break;

        case ESTADO_CHAR:
            escribir_caracter(trans, c);
            if (c == '\\') {
                procesar_escape_en_string(trans);
            } else if (c == '\'') {
                trans->estado = ESTADO_NORMAL;
            }
            break;
    }
}

// =============================================================================
// FUNCIONES DE INICIALIZACIÓN Y LIMPIEZA
// =============================================================================

void inicializar_transpilador(Transpilador *trans, FILE *entrada, FILE *salida) {
    trans->entrada = entrada;
    trans->salida = salida;
    trans->linea_actual = 1;
    trans->tiene_errores = 0;
    trans->estado = ESTADO_NORMAL;
    trans->pos_palabra = 0;
    memset(trans->buffer_palabra, 0, MAX_PALABRA);
}

int abrir_archivos(const char *archivo_entrada, const char *archivo_salida,
                   FILE **entrada, FILE **salida) {
    *entrada = fopen(archivo_entrada, "r");
    if (!*entrada) {
        perror("Error al abrir archivo de entrada");
        return 0;
    }

    *salida = fopen(archivo_salida, "w");
    if (!*salida) {
        perror("Error al abrir archivo de salida");
        fclose(*entrada);
        return 0;
    }

    return 1;
                   }

                   void cerrar_archivos(FILE *entrada, FILE *salida) {
                       if (entrada) fclose(entrada);
                       if (salida) fclose(salida);
                   }

                   // =============================================================================
                   // FUNCIÓN PRINCIPAL
                   // =============================================================================

                   int main(int argc, char *argv[]) {
                       if (argc < 3) {
                           printf("Uso: %s <entrada.es> <salida.c>\n", argv[0]);
                           printf("Transpila código de español a C\n");
                           return 1;
                       }

                       FILE *entrada, *salida;
                       if (!abrir_archivos(argv[1], argv[2], &entrada, &salida)) {
                           return 1;
                       }

                       Transpilador trans;
                       inicializar_transpilador(&trans, entrada, salida);

                       // Procesar cada carácter del archivo
                       int c;
                       while ((c = fgetc(entrada)) != EOF) {
                           procesar_caracter(&trans, c);
                       }

                       // Procesar última palabra si existe
                       procesar_palabra_completa(&trans);

                       cerrar_archivos(entrada, salida);

                       // Mostrar resultado
                       if (trans.tiene_errores) {
                           printf("Transpilación completada con errores. Revisa los mensajes.\n");
                           return 1;
                       } else {
                           printf("Transpilación exitosa: %s -> %s\n", argv[1], argv[2]);
                           return 0;
                       }
                   }
