// Este es un comentario con palabras reservadas: entero, si, retornar
/* Otro comentario:
   mientras, para, sino, vacio
   Nada de esto debe cambiarse.
*/
#include <stdio.h>
int main() {
    int numero = 5;
    char letra = 'a';
    float decimal = 3.14;

    // Imprimir un mensaje (no debe traducir dentro de la cadena)
    printf("El numero es entero y retornaremos un valor\n");

    if(numero > 0) {
        return 0;
    } else {
        return -1;
    }
}
